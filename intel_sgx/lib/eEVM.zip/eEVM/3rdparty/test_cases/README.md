These test cases come from the [ethereum/tests repo](https://github.com/ethereum/tests). They are a subset of the VMTests directory, reformatted into single files.

They are parsed and run as part of the test suite by [tests/harness.cpp](../../tests/harness.cpp).

Current version is [428842e](https://github.com/ethereum/tests/tree/428842e9731b7065366dcd7829bbfc0f9e1135fa), retrieved 19/06/2018.